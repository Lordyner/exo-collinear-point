import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FastCollinearPoints {
    
    private LineSegment[] segments;
    private int nbSegments = 0;

    
//    public FastCollinearPoints(Point[] points) {
//        if (points == null) throw new IllegalArgumentException();
//        for (Point point : points) {
//            if (point == null) throw new IllegalArgumentException();
//        }
//        Point[] sortedPoints = points.clone();
//        Arrays.sort(sortedPoints);
//        for (int i = 0; i < sortedPoints.length - 1; i++) {
//            if (sortedPoints[i].compareTo(sortedPoints[i + 1]) == 0) throw new IllegalArgumentException();
//        }
//        List<LineSegment> segmentList = new ArrayList<>();
//        for (int i = 0; i < sortedPoints.length - 3; i++) {
//            Arrays.sort(sortedPoints, sortedPoints[i].slopeOrder());
//            for (int p = 0, first = 1, last = 2; last < sortedPoints.length; last++) {
//                while (last < sortedPoints.length && Double.compare(sortedPoints[p].slopeTo(sortedPoints[first]), sortedPoints[p].slopeTo(sortedPoints[last])) == 0) {
//                    last++;
//                }
//                if (last - first >= 3 && sortedPoints[p].compareTo(sortedPoints[first]) < 0) {
//                    segmentList.add(new LineSegment(sortedPoints[p], sortedPoints[last - 1]));
//                }
//                first = last;
//            }
//        }
//        segments = segmentList.toArray(new LineSegment[0]);
//    }
    
    public FastCollinearPoints(Point[] points) {
        if (points == null) throw new IllegalArgumentException();
        for (Point point : points) {
            if (point == null) throw new IllegalArgumentException();
        }
        Point[] sortedPoints = points.clone();
        Arrays.sort(sortedPoints);
        for (int i = 0; i < sortedPoints.length - 1; i++) {
            if (sortedPoints[i].compareTo(sortedPoints[i + 1]) == 0) throw new IllegalArgumentException();
        }
        List<LineSegment> segmentList = new ArrayList<>();
        for (int i = 0; i < sortedPoints.length - 3; i++) {
            Arrays.sort(sortedPoints, i + 1, sortedPoints.length, sortedPoints[i].slopeOrder());
            int first = i + 1;
            for (int p = first + 1; p < sortedPoints.length; p++) {
                if (Double.compare(sortedPoints[i].slopeTo(sortedPoints[first]), sortedPoints[i].slopeTo(sortedPoints[p])) != 0) {
                    if (p - first >= 3) {
                        addSegment(segmentList, sortedPoints, i, first, p);
                    }
                    first = p;
                }
            }
            if (sortedPoints.length - first >= 3) {
                addSegment(segmentList, sortedPoints, i, first, sortedPoints.length);
            }
        }
        segments = segmentList.toArray(new LineSegment[segmentList.size()]);
    }

    private void addSegment(List<LineSegment> segmentList, Point[] points, int i, int first, int last) {
        Arrays.sort(points, first, last);
        if (points[first].compareTo(points[i]) >= 0) {
            return;
        }
        segmentList.add(new LineSegment(points[i], points[last - 1]));
        nbSegments++;
    }


    
    public int numberOfSegments() {
        // the number of line segments
        return getNumberOfSegments();
    }
    public LineSegment[] segments() {
        return getSegments();
    }
    
    private int getNumberOfSegments() {
        return nbSegments;
    }
    
    private LineSegment[] getSegments() {
        return segments;
    }
    
}
