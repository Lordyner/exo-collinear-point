import java.util.Arrays;

public class FastCollinearPoints {
    
    private LineSegment[] segments;
    private LineSegment[] aux;
    private int nbSegments = 0;
    
    public FastCollinearPoints(Point[] points)  {
        // finds all line segments containing 4 or more points
        if (points == null) throw new IllegalArgumentException();  
        segments = new LineSegment[0];
        int counterCollinear = 0;
        for (int p = 0; p <= points.length; p++) {
            for (int q = p+1; q <= points.length; q++) {
                if (q < points.length -1 && points[p].slopeOrder().compare(points[q], points[q+1]) == 1) {
                    Point auxPoint = points[q];
                    points[q] = points[q+1];
                    points[q+1] = auxPoint;
                    
                } else if (q < points.length -1 && points[p].slopeOrder().compare(points[q], points[q+1]) == 0) {
                    counterCollinear++;
                }
                
                if (counterCollinear > 3) {     
                    aux = Arrays.copyOf(segments, segments.length+1);                              
                    segments = aux; 
                    segments[segments.length-1] = new LineSegment(points[p], points[q]);
                }
            } 
            counterCollinear = 0;
            
        }
        
       
    }
    
    private static void merge(Point[] a, Point[] aux, int lo, int mid, int hi) {
        for (int k = lo; k <= hi; k++)
            aux[k] = a[k];
            
            int i = lo, j = mid+1;
            for (int k = lo; k <= hi; k++) {
                if (i > mid) a[k] = aux[j++];
                else if (j > hi) a[k] = aux[i++];
                else if (aux[j].compareTo(aux[i]) == 1) a[k] = aux[j++];
                else a[k] = aux[i++];
            }
    }
    
    public int numberOfSegments() {
        // the number of line segments
        return nbSegments;
    }
    public LineSegment[] segments() {
        return segments;
    }
}
